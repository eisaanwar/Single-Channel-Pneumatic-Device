function [dataTime, dataFibre] = SendStartSignal(s, waitMRI)
    disp("Sending Start Singal")
    if(waitMRI)
        writeline(s,"Strt:1") %wait for MRI
    else
        writeline(s,"Strt:0") %run immediately
    end
    pause(0.1);
    disp("Returned ID: ")
    disp(readline(s));

    disp(readline(s));  
    [dataTime, dataFibre] = ReadData(s);
    
    %read data here/ wait for first singla run on timer and then call and
    %run every 1 ms?
end
function UploadHandTapData(s, fileLocation)
    %input file
    inputFile = readmatrix(fileLocation);
    dataInLine = strings(1, size(inputFile, 1)); %empty cell array to hold the string values

    for i = 1:size(inputFile, 1)
        dataInLine(i) = strcat(num2str(inputFile(i,1)), ',',  num2str(inputFile(i,2)), ',',  num2str(inputFile(i,3)));
    end

    commandToSend = "Hand:" + strjoin(dataInLine, ":"); % Join the values with a dash "-" without trailing spaces or dashe
    disp(commandToSend); % Display the final command string

    flush(s);
    disp("sendingHand")
    writeline(s,commandToSend)

    disp("Returned ID: ")
    disp(readline(s));

    disp("Returned Command: ")
    disp(readline(s));
end
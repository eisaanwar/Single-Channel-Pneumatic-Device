function [dataTime, dataFibre] = ReadData(s) 
    %dataTime = [];
    %dataFibre = [];
    dataIn = {};
    pause(0.1)
    while true
        if s.NumBytesAvailable > 0
            current = readline(s);
            disp(current);
            if strcmp(strtrim(current),'fin')
                disp('finished');
                break; %exit loop if finished
            end
            
            %splitValues = strsplit(current, ',');
            
            dataIn{end+1} = current; % is its the right data
            %    dataTime(end+1) = splitValues{2};
            %    dataFibre(end+1) = splitValues{3};
            %end
        else
            disp('No data available');
            %break;  % Exit loop if no data is available
        end
    end
    
    %put the data into vectors
    dataTime = NaN(length(dataIn),1);
    dataFibre = NaN(length(dataIn),1);
    for i = 1:length(dataIn)
        splitValues = strsplit(dataIn{i}, ','); %split at comma
        if(length(splitValues) == 4) %if correct data
            dataTime(i) = str2double(splitValues{2});
            dataFibre(i) = str2double(splitValues{4});
        end
    end
    dataTime = rmmissing(dataTime);
    dataFibre = rmmissing(dataFibre);
end
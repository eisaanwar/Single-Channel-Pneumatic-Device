function [dataTime, dataFibre] = SendTestSignal(s)% MRI or no as argument
    disp("testing")
    %global s;
    writeline(s,"Test:")
    pause(0.5)
    disp("Returned ID: ");
    %dataFirst = readline(s); %need to read the first to make it start? try
    [dataTime, dataFibre] = ReadData(s);
end
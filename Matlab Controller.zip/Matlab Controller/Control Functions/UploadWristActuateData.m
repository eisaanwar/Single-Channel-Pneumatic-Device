function UploadWristActuateData(s, fileLocation)
    %Input file
    inputFile = readmatrix(fileLocation);

    dataInLine = strings(1, size(inputFile, 1)); 

    for i = 1:size(inputFile, 1)
        dataInLine(i) = string(inputFile(i));
    end
    
    inLineData = strjoin(dataInLine, "");
    commandToSend = "Wrst:" + strjoin(dataInLine, ":"); % Join the values with a dash "-" without trailing spaces or dashes
    disp(commandToSend);
    
    flush(s);
    disp("sendingHand")
    writeline(s,commandToSend)

    disp("Returned ID: ")
    disp(readline(s));

    disp("Returned Command: ")
    returnedCommand = strtrim(readline(s));

    %check data is correct
    disp(returnedCommand);
    disp(inLineData);
    if(strcmp(inLineData,returnedCommand))
        disp("data verified")
    else
        disp("data error")
    end

end
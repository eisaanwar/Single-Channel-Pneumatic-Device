clear all
addpath('Control Functions');
serialportlist("available")
%pnewmaticDevice = serialport("/dev/cu.usbmodem101",115200); %mac
pnewmaticDevice = serialport("COM4",115200); %windows
disp("connected")
flush(pnewmaticDevice);

UploadWristActuateData(pnewmaticDevice,"C:\Users\eisaa\OneDrive\Documents\Kings Medical Robot\Input Files\wristTest2.csv");
pause(0.1);
[dataTime, dataFibre] = SendStartSignal(pnewmaticDevice, true); % false to run immediately, true to wait for MRI signal
%wrist fucntion needs to wait for the MRI to interate through the examples
